package main.java.com.app;

public class Application {

    public static void main(String[] args) {
            int capacity = 5;
            int messageCount = 10;
            MessageQueue queue = new MessageQueue(capacity);
            Producer producer = new Producer(queue, messageCount);
            Consumer consumer = new Consumer(queue);
            Thread producerThread = new Thread(producer);
            Thread consumerThread = new Thread(consumer);
            producerThread.start();
            consumerThread.start();
            try {
                producerThread.join();
                consumerThread.interrupt();
                consumerThread.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            AppLogger.log("Application finished. Check the log file for details.");
        }


}