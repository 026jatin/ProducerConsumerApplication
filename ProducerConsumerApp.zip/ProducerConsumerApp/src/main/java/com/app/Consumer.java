package main.java.com.app;

public class Consumer implements Runnable {
    private final MessageQueue queue;
    private int successfulMessages = 0;
    private int errorMessages = 0;
    public Consumer(MessageQueue queue) {
        this.queue = queue;
    }
    @Override
    public void run() {
        while (!Thread.currentThread().isInterrupted()) {
            try {
                String message = queue.consume();
                AppLogger.log("Consumed: " + message);
                successfulMessages++;
            } catch (InterruptedException e) {
                errorMessages++;
                AppLogger.log("Consumer error: " + e.getMessage());
                Thread.currentThread().interrupt();
            }
        }
        AppLogger.log("Consumer Stats - Success: " + successfulMessages + ", Errors: " + errorMessages);
    }
}
