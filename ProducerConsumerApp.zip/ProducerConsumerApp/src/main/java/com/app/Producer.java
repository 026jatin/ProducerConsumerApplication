package main.java.com.app;

public class Producer implements Runnable {
    private final MessageQueue queue;
    private final int messageCount;

    public Producer(MessageQueue queue, int messageCount) {
        this.queue = queue;
        this.messageCount = messageCount;
    }

    @Override
    public void run() {
       for(int i = 1; i<=messageCount; i++) {
           String message = "Message-" +i;
           try {
               queue.produce(message);
               AppLogger.log("Produced:"+message);
           } catch (InterruptedException e) {
               AppLogger.log("Producer error:"+ e.getMessage());
               Thread.currentThread().interrupt();
           }
       }
    }

}
