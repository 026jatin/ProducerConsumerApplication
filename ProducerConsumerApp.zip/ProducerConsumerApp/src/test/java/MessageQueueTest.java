package test.java;

import main.java.com.app.MessageQueue;
import org.junit.jupiter.api.Test;

import static org.junit.Assert.assertEquals;


public class MessageQueueTest {

    @org.junit.Test
    @Test
    public void testProduceConsume() throws InterruptedException {
        MessageQueue queue = new MessageQueue(2);
        // Test producing and consuming a single item
        queue.produce("Test1");
        assertEquals("Test1", queue.consume(), "Test1");
        // Test producing multiple items
        queue.produce("Test2");
        queue.produce("Test3");
        assertEquals("Test2", queue.consume(), "Test2");
        assertEquals("Test3", queue.consume(), "Test3");
    }

}
