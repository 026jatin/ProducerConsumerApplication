//package test.java;
//
//import main.java.com.app.Consumer;
//import main.java.com.app.MessageQueue;
//import main.java.com.app.Producer;
//import org.junit.jupiter.api.Test;
//
//import org.junit.jupiter.api.Test;
//import static org.junit.jupiter.api.Assertions.*;
//public class MessageQueueTest {
//    @Test
//    public void testProduceConsume() throws InterruptedException {
//        MessageQueue queue = new MessageQueue(2);
//        // Test producing and consuming a single item
//        queue.produce("Test1");
//        assertEquals("Test1", queue.consume(), "The consumed message should be 'Test1'");
//        // Test producing multiple items
//        queue.produce("Test2");
//        queue.produce("Test3");
//        assertEquals("Test2", queue.consume(), "The consumed message should be 'Test2'");
//        assertEquals("Test3", queue.consume(), "The consumed message should be 'Test3'");
//    }
//    @Test
//    public void testConsumerWaitsWhenQueueIsEmpty() {
//        MessageQueue queue = new MessageQueue(2);
//        Thread consumer = new Thread(() -> {
//            try {
//                String message = queue.consume();
//                assertEquals("Test4", message, "Consumer should wait until 'Test4' is produced");
//            } catch (InterruptedException e) {
//                fail("Consumer thread was interrupted unexpectedly");
//            }
//        });
//        consumer.start();
//        try {
//            Thread.sleep(500); // Allow consumer to wait on the empty queue
//            queue.produce("Test4");
//        } catch (InterruptedException e) {
//            fail("Main thread was interrupted unexpectedly");
//        }
//        try {
//            consumer.join();
//        } catch (InterruptedException e) {
//            fail("Failed to join the consumer thread");
//        }
//    }
//    @Test
//    public void testProducerWaitsWhenQueueIsFull() {
//        MessageQueue queue = new MessageQueue(2);
//        Thread producer = new Thread(() -> {
//            try {
//                queue.produce("Test5");
//                queue.produce("Test6");
//                queue.produce("Test7"); // Should wait until a slot is freed
//                assertTrue(true, "Producer successfully waited and produced 'Test7'");
//            } catch (InterruptedException e) {
//                fail("Producer thread was interrupted unexpectedly");
//            }
//        });
//        producer.start();
//        try {
//            Thread.sleep(500); // Allow producer to fill the queue
//            assertEquals("Test5", queue.consume(), "Consumed message should be 'Test5'");
//            assertEquals("Test6", queue.consume(), "Consumed message should be 'Test6'");
//        } catch (InterruptedException e) {
//            fail("Main thread was interrupted unexpectedly");
//        }
//        try {
//            producer.join();
//        } catch (InterruptedException e) {
//            fail("Failed to join the producer thread");
//        }
//    }
//    @Test
//    public void testQueueHandlesConcurrentProduceConsume() throws InterruptedException {
//        MessageQueue queue = new MessageQueue(3);
//        Thread producer = new Thread(() -> {
//            try {
//                queue.produce("Test8");
//                queue.produce("Test9");
//                queue.produce("Test10");
//            } catch (InterruptedException e) {
//                fail("Producer thread was interrupted unexpectedly");
//            }
//        });
//        Thread consumer = new Thread(() -> {
//            try {
//                assertEquals("Test8", queue.consume(), "Consumer should receive 'Test8'");
//                assertEquals("Test9", queue.consume(), "Consumer should receive 'Test9'");
//                assertEquals("Test10", queue.consume(), "Consumer should receive 'Test10'");
//            } catch (InterruptedException e) {
//                fail("Consumer thread was interrupted unexpectedly");
//            }
//        });
//        producer.start();
//        consumer.start();
//        producer.join();
//        consumer.join();
//    }
//}
